# YT-Mushell Installation Guide
## 安裝指南

### Step 1: Install MPV Player
### 步驟 1：安裝 MPV 播放器

**Download MPV:**
**下載 MPV：**

1. Download from direct link:
   直接下載連結：
   https://github.com/zhongfly/mpv-winbuild/releases/download/2025-10-31-d3ec15b/mpv-x86_64-20251031-git-d3ec15b.7z

2. Extract all files to `third_party\mpv\` folder
   解壓所有檔案到 `third_party\mpv\` 資料夾

3. Verify `third_party\mpv\mpv.exe` exists (~100MB)
   確認 `third_party\mpv\mpv.exe` 存在（約 100MB）

### Step 2: Configure YouTube Music
### 步驟 2：設定 YouTube Music

1. Run `get-ytmusic-config.js` in your browser console at https://music.youtube.com
   在 https://music.youtube.com 的瀏覽器控制台執行 `get-ytmusic-config.js`

2. Copy the output to `config\ytmusic.json`
   將輸出複製到 `config\ytmusic.json`

### Step 3: Run
### 步驟 3：執行

```bash
.\YT-mushell.exe "song name"
```

### Troubleshooting
### 疑難排解

**Cannot find MPV:**
**找不到 MPV：**
- Make sure `third_party\mpv\mpv.exe` exists
- 確保 `third_party\mpv\mpv.exe` 存在
- Download from https://github.com/zhongfly/mpv-winbuild/releases
- 從 https://github.com/zhongfly/mpv-winbuild/releases 下載

**Cannot search songs:**
**無法搜尋歌曲：**
- Check `config\ytmusic.json` is configured correctly
- 檢查 `config\ytmusic.json` 是否正確設定
- Cookie may have expired - run `get-ytmusic-config.js` again
- Cookie 可能過期 - 重新執行 `get-ytmusic-config.js`
