# ⚠️ MPV Player Required
# ⚠️ 需要 MPV 播放器

This folder should contain MPV player binaries.
此資料夾應包含 MPV 播放器執行檔。

## Installation / 安裝

Download MPV from:
從以下位置下載 MPV：

**Direct Download Link:**
**直接下載連結：**

https://github.com/zhongfly/mpv-winbuild/releases/download/2025-10-31-d3ec15b/mpv-x86_64-20251031-git-d3ec15b.7z

Or browse releases:
或瀏覽所有版本：
https://github.com/zhongfly/mpv-winbuild/releases

Extract all files to this folder. Required files include:
解壓所有檔案到此資料夾。必需的檔案包括：

- mpv.exe (~100MB)
- mpv.com (~3.5KB)
- Various DLL files

## Why is MPV not included?
## 為什麼不包含 MPV？

MPV binaries are ~100MB and would make the repository too large.
MPV 執行檔約 100MB，會使儲存庫過大。

Please download it manually from the link above.
請從上方連結手動下載。
